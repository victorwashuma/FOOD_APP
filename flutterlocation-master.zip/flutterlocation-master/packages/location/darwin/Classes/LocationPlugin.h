#import <Flutter/Flutter.h>

@interface LocationPlugin : NSObject <FlutterPlugin>
@end
