package com.lyokone.location.example;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {}
