#import <FlutterMacOS/FlutterMacOS.h>

@interface LocationPlugin : NSObject <FlutterPlugin>
@end
